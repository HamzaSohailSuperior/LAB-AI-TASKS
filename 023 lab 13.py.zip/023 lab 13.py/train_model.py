import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import joblib

# Load the dataset
gold_data = pd.read_csv('gld_price_data.csv')

# Drop missing values (if any)
gold_data = gold_data.dropna()

# Prepare data
X = gold_data.drop(['Date', 'GLD'], axis=1)
Y = gold_data['GLD']

# Split data
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=2)

# Train model
regressor = RandomForestRegressor(n_estimators=100)
regressor.fit(X_train, Y_train)

# Save the trained model to file
joblib.dump(regressor, 'model.pkl')

print("✅ Model saved as model.pkl")
