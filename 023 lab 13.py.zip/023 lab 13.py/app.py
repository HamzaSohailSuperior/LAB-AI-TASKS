# app.py

from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import joblib

app = Flask(__name__)

# Load trained model
model = joblib.load('model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract user input
        SPX = float(request.form['SPX'])
        USO = float(request.form['USO'])
        SLV = float(request.form['SLV'])
        EURUSD = float(request.form['EURUSD'])

        # Make prediction
        input_data = np.array([[SPX, USO, SLV, EURUSD]])
        prediction = model.predict(input_data)

        return render_template('index.html', prediction_text=f"Predicted Gold Price: ${prediction[0]:.2f}")
    except:
        return render_template('index.html', prediction_text="❌ Invalid input. Please enter valid numbers.")

if __name__ == '__main__':
    app.run(debug=True)
