"Lab 9: Netflix Dataset Exploration"

import pandas as pd
import matplotlib.pyplot as plt

"Load the dataset"
df = pd.read_csv("netflix_titles.csv")
print("✅ Netflix Dataset Loaded!\n")

"Show first few rows"
print("🔹 First 5 Rows:")
print(df.head())

"Dataset shape"
print("\n🔹 Dataset Shape:", df.shape)

"Info summary"
print("\n🔹 Dataset Info:")
print(df.info())

"Statistical summary (only works on numerical columns)"
print("\n🔹 Statistical Summary:")
print(df.describe())

"Missing values"
print("\n🔹 Missing Values:")
print(df.isnull().sum())

"Unique values per column"
print("\n🔹 Unique Values per Column:")
for col in df.columns:
    print(f"{col}: {df[col].nunique()}")

"Value counts for type (Movie vs TV Show)"
print("\n🔹 Content Type Count:")
type_counts = df['type'].value_counts()
print(type_counts)

"Top 10 countries with most content"
print("\n🔹 Top 10 Countries with Most Content:")
country_counts = df['country'].value_counts().head(10)
print(country_counts)

"Plot: Movies vs TV Shows using Matplotlib"
plt.figure(figsize=(6, 4))
plt.bar(type_counts.index, type_counts.values, color=['red', 'blue'])
plt.title("Number of Movies vs TV Shows on Netflix")
plt.xlabel("Content Type")
plt.ylabel("Count")
plt.grid(axis='y')
plt.tight_layout()
plt.show()
