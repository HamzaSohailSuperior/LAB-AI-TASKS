from flask import Flask, render_template, request
import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Initializing Flask app
app = Flask(__name__)

def train_model():
    # Load dataset
    data = pd.read_csv('netflix_titles.csv')

    # Splitting features and labels
    X = data.iloc[:, :-1]  # Features (all columns except the last)
    y = data.iloc[:, -1]   # Labels (last column)

    # Encode categorical columns
    cat_columns = X.select_dtypes(['object']).columns
    X[cat_columns] = X[cat_columns].apply(lambda col: pd.factorize(col)[0])

    # Scale the data (can include negative values)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Split data into train/test
    X_train, X_test, Y_train, Y_test = train_test_split(X_scaled, y, test_size=0.3)

    # Train model with GaussianNB
    model = GaussianNB()
    model.fit(X_train, Y_train)

    # Evaluate model
    Y_pred = model.predict(X_test)
    accuracy = accuracy_score(Y_test, Y_pred)
    print(f'Model Accuracy: {accuracy:.2f}')

    return model, scaler

# Train and load model
model, scaler = train_model()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Collect features from the form
        features = [float(x) for x in request.form.values()]
        features = [features]  # Convert to 2D list for model input

        # Scale features
        features_scaled = scaler.transform(features)

        # Predict
        prediction = model.predict(features_scaled)

        return render_template('index.html', prediction_text=f'Prediction: {prediction[0]}')

if __name__ == "__main__":
    app.run(debug=True)
