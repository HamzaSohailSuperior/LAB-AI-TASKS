# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB  # Using GaussianNB instead of MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.metrics import accuracy_score
from flask import Flask, render_template, request
from sklearn.preprocessing import StandardScaler
import pickle  # Used for saving the model

# Initialize Flask app
app = Flask(__name__)

# Train the model
def train_model():
    data = pd.read_csv('netflix_titles.csv')  # Load dataset
    X = data.iloc[:, :-1]  # Features
    y = data.iloc[:, -1]   # Labels
    
    # Convert object columns to integers
    cat_columns = X.select_dtypes(['object']).columns
    X[cat_columns] = X[cat_columns].apply(lambda x: pd.factorize(x)[0])

    # Check for negative values after factorization
    if (X < 0).any().any():
        print("Warning: Negative values found in features. Consider handling them properly.")

    # Scaling data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Split dataset into train and test
    X_train, X_test, Y_train, Y_test = train_test_split(X_scaled, y, test_size=0.3)

    # Use GaussianNB instead of MultinomialNB
    model = GaussianNB()
    model.fit(X_train, Y_train)

    # Model evaluation
    Y_pred = model.predict(X_test)
    accuracy = accuracy_score(Y_test, Y_pred)
    print(f'Model Accuracy: {accuracy}')

    # Save the model and scaler for later use in Flask app
    with open('model.pkl', 'wb') as model_file:
        pickle.dump(model, model_file)
    with open('scaler.pkl', 'wb') as scaler_file:
        pickle.dump(scaler, scaler_file)

    return model, scaler

# Load the trained model and scaler
def load_model_and_scaler():
    with open('model.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    with open('scaler.pkl', 'rb') as scaler_file:
        scaler = pickle.load(scaler_file)
    return model, scaler

# Initialize the model and scaler
train_model()

# Load the trained model for use in the Flask routes
model, scaler = load_model_and_scaler()

@app.route('/')
def home():
    return render_template('index.html')  # Serve the HTML frontend

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Collect input data from the frontend
        features = [float(x) for x in request.form.values()]
        features = [features]  # Reshape to 2D array
        
        # Scale the input data
        features_scaled = scaler.transform(features)
        
        # Make prediction
        prediction = model.predict(features_scaled)
        
        # Return prediction result to frontend
        return render_template('index.html', prediction_text=f'Prediction: {prediction[0]}')

if __name__ == "__main__":
    app.run(debug=True)
