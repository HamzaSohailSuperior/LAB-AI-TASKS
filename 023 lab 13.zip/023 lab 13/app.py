from flask import Flask, render_template, request
import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Initializing Flask app
app = Flask(__name__)

def train_model():
    # Load dataset
    data = pd.read_csv('netflix_titles.csv')

    # Use only a subset of features for demonstration
    features = ['type', 'release_year', 'rating']
    label = 'title'  # Predict the title

    X = data[features].copy()
    y, title_uniques = pd.factorize(data[label])  # Encode titles

    # Encode categorical columns
    X['type'] = pd.factorize(X['type'])[0]
    X['rating'] = pd.factorize(X['rating'])[0]

    # Scale the data (can include negative values)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Split data into train/test
    X_train, X_test, Y_train, Y_test = train_test_split(X_scaled, y, test_size=0.3)

    # Train model with GaussianNB
    model = GaussianNB()
    model.fit(X_train, Y_train)

    # Evaluate model
    Y_pred = model.predict(X_test)
    accuracy = accuracy_score(Y_test, Y_pred)
    print(f'Model Accuracy: {accuracy:.2f}')

    return model, scaler, title_uniques

# Train and load model
model, scaler, title_uniques = train_model()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get form values
        type_input = request.form['type']
        release_year = float(request.form['release_year'])
        rating_input = request.form['rating']

        # Encode categorical inputs (must match training encoding)
        type_map = {'Movie': 0, 'TV Show': 1}
        rating_map = {v: i for i, v in enumerate(pd.read_csv('netflix_titles.csv')['rating'].dropna().unique())}

        type_encoded = type_map.get(type_input, 0)
        rating_encoded = rating_map.get(rating_input, 0)

        features = [[type_encoded, release_year, rating_encoded]]
        features_scaled = scaler.transform(features)
        prediction_idx = model.predict(features_scaled)[0]
        prediction_title = title_uniques[prediction_idx]

        return render_template('index.html', prediction_text=f'Predicted Title: {prediction_title}')

if __name__ == "__main__":
    app.run(debug=True)
