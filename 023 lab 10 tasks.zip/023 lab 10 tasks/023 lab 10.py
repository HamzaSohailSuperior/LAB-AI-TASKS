import pandas as pd
import numpy as np

"Reads the dataset"
df = pd.read_csv("netflix_titles.csv")
print("✅ Netflix Dataset Loaded")

"Shows rows and columns"
print(f"We have {df.shape[0]} rows.")
print(f"We have {df.shape[1]} columns\n")

"Check null values"
print("🔹 Null Values in Each Column:")
print(df.isnull().sum())

"Check unique values of specific column (e.g., 'rating')"
print("\n🔹 Unique Ratings:")
print(df['rating'].unique())

"Filling missing values in 'rating' column with the mode"
rating_mode = df['rating'].mode()[0]
df['rating'] = df['rating'].fillna(rating_mode)

"Filling missing values in 'country' with mode"
country_mode = df['country'].mode()[0]
df['country'] = df['country'].fillna(country_mode)

"Filling other missing string columns (like 'director') with Unknown"
df['director'] = df['director'].fillna("Unknown")
df['cast'] = df['cast'].fillna("Unknown")

"Filling 'date_added' as string Unknown"
df['date_added'] = df['date_added'].fillna("Unknown")

"Converting 'release_year' to integer"
df['release_year'] = df['release_year'].astype(np.int64)

"Dropping unnecessary columns (e.g., 'show_id')"
df.drop('show_id', axis=1, inplace=True)

"Checking datatypes"
print("\n🔹 Data Types:")
print(df.dtypes)

"Spliting into X and y"
X = df.iloc[:, 1:]  
y = df['type']
print("\nX shape:", X.shape)
print("y shape:", y.shape)

"Converting object columns in X to integers"
cat_columns = X.select_dtypes(['object']).columns
X[cat_columns] = X[cat_columns].apply(lambda col: pd.factorize(col)[0])

print("\n✅ All categorical features in X converted to integers.")
print(X.head())
