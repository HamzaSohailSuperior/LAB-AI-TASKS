"Importing necessary libraries"
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import BernoulliNB, MultinomialNB, GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.metrics import accuracy_score

"Step 1: Loading the dataset"
data = pd.read_csv("netflix_titles.csv")

"Spliting into x and y"
x = data.iloc[:, 0:-1]
y = data.iloc[:, -1]

"Convert object columns to integers"
cat_columns = x.select_dtypes(['object']).columns
x[cat_columns] = x[cat_columns].apply(lambda x: pd.factorize(x)[0])

"Split into train and test"
X_train, X_test, Y_train, Y_test = train_test_split(x, y, test_size=0.3, shuffle=False)

"Applying classifiers and get metrics"

"BernoulliNB"
BernNB = BernoulliNB()
BernNB.fit(X_train, Y_train)
Y_bpred = BernNB.predict(X_test)
b_accuracy = accuracy_score(Y_test, Y_bpred)
b_precision = metrics.precision_score(Y_test, Y_bpred, average='weighted', labels=np.unique(Y_bpred))
b_recall = metrics.recall_score(Y_test, Y_bpred, average='weighted', labels=np.unique(Y_bpred))
b_f1 = metrics.f1_score(Y_test, Y_bpred, average='weighted', labels=np.unique(Y_bpred))

"Random Forest"
RF = RandomForestClassifier()
RF.fit(X_train, Y_train)
Y_rpred = RF.predict(X_test)
r_accuracy = accuracy_score(Y_test, Y_rpred)
r_precision = metrics.precision_score(Y_test, Y_rpred, average='weighted', labels=np.unique(Y_rpred))
r_recall = metrics.recall_score(Y_test, Y_rpred, average='weighted', labels=np.unique(Y_rpred))
r_f1 = metrics.f1_score(Y_test, Y_rpred, average='weighted', labels=np.unique(Y_rpred))

"GaussianNB"
GausNB = GaussianNB()
GausNB.fit(X_train, Y_train)
Y_gpred = GausNB.predict(X_test)
g_accuracy = accuracy_score(Y_test, Y_gpred)
g_precision = metrics.precision_score(Y_test, Y_gpred, average='weighted', labels=np.unique(Y_gpred))
g_recall = metrics.recall_score(Y_test, Y_gpred, average='weighted', labels=np.unique(Y_gpred))
g_f1 = metrics.f1_score(Y_test, Y_gpred, average='weighted', labels=np.unique(Y_gpred))

"Decision Tree"
Dtree = DecisionTreeClassifier()
Dtree.fit(X_train, Y_train)
Y_dpred = Dtree.predict(X_test)
d_accuracy = accuracy_score(Y_test, Y_dpred)
d_precision = metrics.precision_score(Y_test, Y_dpred, average='weighted', labels=np.unique(Y_dpred))
d_recall = metrics.recall_score(Y_test, Y_dpred, average='weighted', labels=np.unique(Y_dpred))
d_f1 = metrics.f1_score(Y_test, Y_dpred, average='weighted', labels=np.unique(Y_dpred))

"MultinomialNB"
MultiNB = MultinomialNB()
MultiNB.fit(X_train, Y_train)
Y_mpred = MultiNB.predict(X_test)
m_accuracy = accuracy_score(Y_test, Y_mpred)
m_precision = metrics.precision_score(Y_test, Y_mpred, average='weighted', labels=np.unique(Y_mpred))
m_recall = metrics.recall_score(Y_test, Y_mpred, average='weighted', labels=np.unique(Y_mpred))
m_f1 = metrics.f1_score(Y_test, Y_mpred, average='weighted', labels=np.unique(Y_mpred))

"KNN"
KNN = KNeighborsClassifier()
KNN.fit(X_train, Y_train)
Y_kpred = KNN.predict(X_test)
k_accuracy = accuracy_score(Y_test, Y_kpred)
k_precision = metrics.precision_score(Y_test, Y_kpred, average='weighted', labels=np.unique(Y_kpred))
k_recall = metrics.recall_score(Y_test, Y_kpred, average='weighted', labels=np.unique(Y_kpred))
k_f1 = metrics.f1_score(Y_test, Y_kpred, average='weighted', labels=np.unique(Y_kpred))

"Line Graph for Accuracy, Precision, Recall, F1"
plt.figure(figsize=(16,10))

x_labels = ['Bernoulli', 'Random Forest', 'Gaussian', 'Decision Tree', 'Multinomial', 'KNeighbors']

plt.plot(x_labels, [b_accuracy, r_accuracy, g_accuracy, d_accuracy, m_accuracy, k_accuracy], marker='o', label='Accuracy')
plt.plot(x_labels, [b_precision, r_precision, g_precision, d_precision, m_precision, k_precision], marker='o', label='Precision')
plt.plot(x_labels, [b_recall, r_recall, g_recall, d_recall, m_recall, k_recall], marker='o', label='Recall')
plt.plot(x_labels, [b_f1, r_f1, g_f1, d_f1, m_f1, k_f1], marker='o', label='F1')

plt.title("Scores of Applied Classifiers")
plt.legend()
plt.show()

"Bar Graph for F1 Scores"
left = [1, 2, 3, 4, 5, 6]
height = [b_f1, r_f1, g_f1, d_f1, m_f1, k_f1]
tick_label = ['Bernoulli', 'Random Forest', 'Gaussian', 'Decision Tree', 'Multinomial', 'KNeighbors']

plt.figure(figsize=(16,10))
plt.bar(left, height, tick_label=tick_label, width=0.9, color=['#08737f', '#00898a', '#089f8f', '#39b48e', '#64c987', '#92dc7e'])
plt.xlabel('Classifiers')
plt.ylabel('F1 Scores')
plt.title('F1 Scores of Applied Classifiers')
plt.show()
